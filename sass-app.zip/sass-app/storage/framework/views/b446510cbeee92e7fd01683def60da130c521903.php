<form method="post" action="<?php echo e(action('FlightController@store')); ?>" accept-charset="UTF-8">

<div class="form-group">
    @csrf
    <label for="name">Share Name: </label>
    <input type="text" class="form-control" name="name" value=""/>
</div>

<button type="submit" class="btn btn-primary">Add</button>
</form>