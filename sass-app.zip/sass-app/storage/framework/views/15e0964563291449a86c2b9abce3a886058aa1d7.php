<?php
foreach ($users as $user) {
    echo $user->name . "<br>";
}