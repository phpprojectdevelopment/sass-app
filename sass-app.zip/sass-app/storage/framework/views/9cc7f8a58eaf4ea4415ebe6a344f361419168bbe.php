<?php $__env->startSection('title','| Content '); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div id="slider-wrap" class="">
        <div id="slider" class="carousel slide inner" data-ride="carousel" data-interval="0"
            data-pause="false">
            <div class="carousel-inner">
                <div class="item active">
                    <img src="<?php echo e(asset('public/images/slider/offers-of-month.jpg')); ?>" alt="Viva Honda - Schedule a Test Drive ">
                </div>
            </div>
            <div class="carousel-navigation">
                <a class="left carousel-control" href="#slider" role="button" data-slide="prev"><span
                    class="glyphicon glyphicon-chevron-left icon-left-open-big" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span> </a><a class="right carousel-control" href="#slider"
                        role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right icon-right-open-big"
                            aria-hidden="true"></span><span class="sr-only">Next</span> </a>
            </div>
            <div class="clearfix">
            </div>
        </div>
    </div>
    <div id="PageContent" class="pad30 test-drive">

        <div class="container">
            <h1 class="section-head">Take A Test Drive</h1>
        </div>
        <div class="container">
            <div class="bg-grey">
                <h3 class="sub">
                    Your Details
                </h3>
                <div class="clearfix container-fluid">
                    
                <div class="col-md-6 form-wrap">
                    <div class="row">
                        <div class="col-xs-12 form no-padding">

                            <p style="margin: 0;">
                                <span id="ctl00_ContentPlaceHolder1_lblMessage" class="success"></span>
                            </p>

                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Name*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtName" type="text" id="ctl00_ContentPlaceHolder1_txtName" class="form-control" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvName" class="text-danger" style="display:none;">Please specify name</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Email Id*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtEmail" type="text" id="ctl00_ContentPlaceHolder1_txtEmail" class="form-control" />
                                    <input name="ctl00$ContentPlaceHolder1$txtSecEmail" type="text" id="ctl00_ContentPlaceHolder1_txtSecEmail" class="secemail" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvEmailId" class="text-danger" style="display:none;">Please specify email id.</span>
                                    <span id="ctl00_ContentPlaceHolder1_revEmailId" class="text-danger" style="display:none;">Please enter valid email address</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Contact No*</label>
                                <div class="col-sm-8">
                                    <input name="ctl00$ContentPlaceHolder1$txtContactNo" type="text" id="ctl00_ContentPlaceHolder1_txtContactNo" class="form-control" />
                                    <span id="ctl00_ContentPlaceHolder1_rfvContactNo" class="text-danger" style="display:none;">Please specify contact no.</span>
                                    <span id="ctl00_ContentPlaceHolder1_revTelno" class="text-danger" style="display:none;">Please specify valid contact no.</span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Location</label>
                                <div class="col-sm-8">
                                    <select name="ctl00$ContentPlaceHolder1$ddlLocation" id="ctl00_ContentPlaceHolder1_ddlLocation" class="form-control">
    <option value="-1">Select Location</option>
    <option value="1">Central</option>
    <option value="2">Western</option>

</select>
                                    <span id="ctl00_ContentPlaceHolder1_rfvCity" class="text-danger" style="display:none;">Please select location</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Type" class="col-sm-3 control-label">
                                    Car Model</label>
                                <div class="col-sm-8">
                                    <select name="ctl00$ContentPlaceHolder1$ddlTestDriveModel" id="ctl00_ContentPlaceHolder1_ddlTestDriveModel" class="form-control ddtestdrivemodel">
    <option value="-1" ModelID="-1">Select Car</option>
    <option value="Amaze" ModelID="7">Amaze</option>
    <option value="Jazz" ModelID="8">Jazz</option>
    <option value="City" ModelID="9">City</option>
    <option value="BR-V" ModelID="11">BR-V</option>
    <option value="CR-V" ModelID="12">CR-V</option>
    <option value="Accord-Hybrid" ModelID="13">Accord Hybrid</option>
    <option value="WR-V" ModelID="15">WR-V</option>
    <option value="All-new-Civic" ModelID="16">All new Civic</option>

</select>
                                    <span id="ctl00_ContentPlaceHolder1_rfvCars" class="text-danger" style="display:none;">Please select car model</span>
                                </div>
                            </div>
                           
                                     
                            <label for="Type" class="col-sm-3 control-label">
                            </label>
                            <div class="col-sm-8">
                                <input type="submit" name="ctl00$ContentPlaceHolder1$btnSubmit" value="Submit" onclick="return ReturnValidate();WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ContentPlaceHolder1$btnSubmit&quot;, &quot;&quot;, true, &quot;ValidateTestDrive&quot;, &quot;&quot;, false, false))" id="ctl00_ContentPlaceHolder1_btnSubmit" class="btn btn-viva col-md-4" />
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            
        <div class="container pad">
            
        <p class="no-margin">I agree that by clicking "Submit", I am explicitly soliciting a call or message from the Viva Honda or its associates
on my number to assist me.</p>
        </div>
    </div>


    </div>
    <script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script type="text/javascript">

        $('.LocationToggle').change(function () {
            ShowLocation();
        });

        function ShowLocation() {
            if ($('table[id$="rbLocation"]  input:checked').val() == "1") {
                $('#mylocation').removeClass('hide');
                $('#showroom').addClass('hide');
            }
            else {
                $('#showroom').removeClass('hide');
                $('#mylocation').addClass('hide');
            }
        }
    </script>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>