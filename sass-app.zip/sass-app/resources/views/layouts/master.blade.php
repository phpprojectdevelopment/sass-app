<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <title>Laravel CRUD App Example</title>
      <link rel="stylesheet" href="{{asset('public/css/bootstrap.min.css')}}">
      <script src="{{ asset('public/js/jquery-3.1.1.min.js') }}"></script>
   </head>
   <body>
      <div class="container">
         @yield('content')
      </div>
      <script src="{{-- asset('public/js/bootstrap.min.js') --}}" type="text/js"></script>
   </body>
</html>