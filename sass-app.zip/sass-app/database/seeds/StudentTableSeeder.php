<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use App\Student;

class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($i=0;$i<100;$i++){
        	$student_class = ['First', 'Second', 'Third'];
        	$student_age = [5,6,7,8];
        	$admission_start_date = strtotime("10 September 2000");
        	$admission_end_date = strtotime("22 July 2010");
        	$admission_date = mt_rand($admission_start_date, $admission_end_date);

        	Student::create([
        		'student_name'=>Str::random(10),
        		'class'=>Arr::random($student_class),
        		'age'=>Arr::random($student_age),
        		'admission_date'=> date('Y-m-d', $admission_date)
        	]);
        }
    }
}
